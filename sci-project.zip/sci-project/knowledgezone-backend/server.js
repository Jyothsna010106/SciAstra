require('dotenv').config();

const express = require('express'); 
const mysql = require('mysql2'); 
const bodyParser = require('body-parser'); 
const cors = require('cors'); 
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const bcrypt = require('bcrypt'); // For password hashing
const jwt = require('jsonwebtoken'); // For JWT authentication
const multer = require('multer'); // For handling file uploads
const fs = require('fs'); // For file system operations
const { body, validationResult } = require('express-validator');

const app = express(); 
const server = http.createServer(app);
const io = socketIo(server);
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors()); 
app.use(bodyParser.json()); 

// MySQL Connection
const connection = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

// Connect to the database
connection.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err);
        return;
    }
    console.log('Connected to the database.');
});

// Socket.io connection
io.on('connection', (socket) => {
    console.log('A user connected');
});

// Middleware for JWT authentication
const authenticateJWT = (req, res, next) => {
    const token = req.headers['authorization'] && req.headers['authorization'].split(' ')[1];
    if (token) {
        jwt.verify(token, 'your_jwt_secret', (err, user) => {
            if (err) {
                return res.sendStatus(403);
            }
            req.user = user;
            next();
        });
    } else {
        res.sendStatus(401);
    }
};

// API endpoint to get courses
app.get('/api/courses', (req, res) => {
    connection.query('SELECT * FROM courses', (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});

// API endpoint to get all blogs
app.get('/api/blogs', (req, res) => {
    connection.query('SELECT * FROM blogs', (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});

// API endpoint to create a new blog
app.post('/api/blogs', (req, res) => {
    const { title, content, publishDate } = req.body;
    connection.query('INSERT INTO blogs (title, content, publish_date) VALUES (?, ?, ?)', 
    [title, content, publishDate], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        // Emit an event to notify clients about the new blog
        io.emit('newBlog', { id: results.insertId, title, content, publishDate });
        res.status(201).json({ id: results.insertId, title, content, publishDate });
    });
});

// User registration endpoint with role
app.post('/api/register', [
    body('username').isLength({ min: 3 }).withMessage('Username must be at least 3 characters long.'),
    body('email').isEmail().withMessage('Please enter a valid email address.'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters long.'),
    body('role').isIn(['admin', 'customer']).withMessage('Role must be either admin or customer.')
], async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { username, password, email, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10); // Hash the password

    connection.query('INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)', 
    [username, hashedPassword, email, role], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.status(201).json({ id: results.insertId, username, email, role });
    });
});

// User login endpoint
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    connection.query('SELECT * FROM users WHERE username = ?', [username], async (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const user = results[0];
        const match = await bcrypt.compare(password, user.password); // Compare hashed password
        if (!match) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        // Generate a JWT token
        const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ message: 'Login successful', token, user: { id: user.id, username: user.username, email: user.email, role: user.role } });
    });
});

// User profile endpoint
app.get('/api/profile', authenticateJWT, (req, res) => {
    const userId = req.user.id; // Get user ID from the JWT token

    connection.query('SELECT username, email, joined_date AS joinedDate, bio, profile_picture AS profilePicture FROM users WHERE id = ?', [userId], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }
        res.json(results[0]); // Return the user profile data
    });
});

// Set up multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/'); // Directory to save uploaded files
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname)); // Append timestamp to the filename
    }
});

const upload = multer({ storage });

// Profile picture upload endpoint
app.post('/api/profile/picture', authenticateJWT, upload.single('profilePicture'), (req, res) => {
    const userId = req.user.id;
    const profilePicturePath = req.file.path; // Get the path of the uploaded file

    // Update the user's profile picture in the database
    connection.query('UPDATE users SET profile_picture = ? WHERE id = ?', [profilePicturePath, userId], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json({ message: 'Profile picture updated successfully!', profilePicture: profilePicturePath });
    });
});

// Serve the main HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/menu.html'));
});

// User role selection endpoint (optional)
app.post('/api/role', (req, res) => {
    const { role } = req.body;
    // Here you can handle the role selection logic, e.g., store it in the session or database
    res.json({ message: `Role selected: ${role}` });
});

// Start the server
server.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`); 
});